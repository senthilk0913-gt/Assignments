package casestudy.json.converter.def;

/**
 * @author Senthilkumar
 * 
 * 
 */
public interface XMLJSONConverterI {
	
	void convertJSONtoXML(String JsonFilePath, String xmlFilePath) throws Exception;

}
